import pandas as pd
import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
from pathlib import Path
from database import get_connection


def calculate_consumption():
    connection = None
    cursor = None

    try:
        connection = get_connection()
        cursor = connection.cursor(dictionary=True)

        # Get saved readings along with meter and consumer details.
        cursor.execute("""
            SELECT
                r.reading_id,
                r.meter_id,
                m.meter_code,
                c.consumer_type,
                c.region,
                r.reading_date,
                r.cumulative_kwh
            FROM meter_readings AS r
            INNER JOIN meters AS m
                ON r.meter_id = m.meter_id
            INNER JOIN consumers AS c
                ON m.consumer_id = c.consumer_id
            ORDER BY r.meter_id, r.reading_date, r.reading_id
        """)

        readings = cursor.fetchall()

        if not readings:
            return []

        df = pd.DataFrame(readings)

        # Convert database values to appropriate data types.
        df["reading_date"] = pd.to_datetime(
            df["reading_date"], errors="raise"
        )
        df["cumulative_kwh"] = pd.to_numeric(
            df["cumulative_kwh"], errors="raise"
        )

        # Ensure readings are in chronological order.
        df = df.sort_values(
            ["meter_id", "reading_date", "reading_id"]
        ).reset_index(drop=True)

        # Calculate the difference from the previous reading
        # belonging to the same meter.
        grouped = df.groupby("meter_id", sort=False)

        df["consumption_kwh"] = (
            grouped["cumulative_kwh"].diff()
        )

        df["days_between"] = (
            grouped["reading_date"].diff().dt.days
        )

        # Negative consumption can indicate a meter reset,
        # rollover, or incorrect reading. Flag it for review.
        df["reading_status"] = "Valid"

        df.loc[
            df["consumption_kwh"] < 0,
            "reading_status"
        ] = "Check meter reset or reading"

        # The first reading has no previous reading to compare.
        df.loc[
            df["consumption_kwh"].isna(),
            "reading_status"
        ] = "First reading - consumption unavailable"

        # Convert values into formats suitable for JSON.
        df["reading_date"] = (
            df["reading_date"].dt.strftime("%Y-%m-%d")
        )

        df["cumulative_kwh"] = df["cumulative_kwh"].round(2)
        df["consumption_kwh"] = df["consumption_kwh"].round(2)

        # Replace NaN values with None for valid JSON responses.
        df = df.astype(object).where(pd.notna(df), None)

        return df.to_dict(orient="records")

    finally:
        if cursor is not None:
            cursor.close()

        if connection is not None and connection.is_connected():
            connection.close()


def generate_consumption_chart():
    data = calculate_consumption()

    # Exclude first readings and invalid negative intervals.
    valid_data = [
        item for item in data
        if item["consumption_kwh"] is not None
        and item["consumption_kwh"] >= 0
    ]

    folder = Path(__file__).resolve().parent / "static"
    folder.mkdir(parents=True, exist_ok=True)

    chart_path = folder / "consumption_chart.png"

    fig, ax = plt.subplots(figsize=(9, 5))

    if valid_data:
        labels = [
            f'{item["meter_code"]}\n{item["reading_date"]}'
            for item in valid_data
        ]

        values = [
            float(item["consumption_kwh"])
            for item in valid_data
        ]

        ax.bar(labels, values, label="Electricity consumption")
        ax.legend()
    else:
        ax.text(
            0.5,
            0.5,
            "No consumption data available yet",
            ha="center",
            va="center",
            transform=ax.transAxes
        )

    ax.set_title("Electricity Consumption Analysis")
    ax.set_xlabel("Meter and Reading Date")
    ax.set_ylabel("Consumption (kWh)")
    ax.grid(axis="y", linestyle="--", alpha=0.4)

    fig.tight_layout()
    fig.savefig(chart_path)
    plt.close(fig)

    return str(chart_path)


def generate_consumption_summary():
    data = calculate_consumption()

    if not data:
        return {"monthly": [], "yearly": []}

    df = pd.DataFrame(data)

    # Ignore first readings and invalid negative intervals.
    df = df[
        df["consumption_kwh"].notna()
        & (df["consumption_kwh"] >= 0)
    ].copy()

    if df.empty:
        return {"monthly": [], "yearly": []}

    df["reading_date"] = pd.to_datetime(df["reading_date"])
    df["consumption_kwh"] = pd.to_numeric(
        df["consumption_kwh"]
    )

    # Assign interval consumption to the month and year
    # of the later reading.
    df["month"] = df["reading_date"].dt.strftime("%Y-%m")
    df["year"] = df["reading_date"].dt.year

    monthly_df = (
        df.groupby(
            ["meter_code", "month"], as_index=False
        )["consumption_kwh"]
        .sum()
        .round(2)
    )

    yearly_df = (
        df.groupby(
            ["meter_code", "year"], as_index=False
        )["consumption_kwh"]
        .sum()
        .round(2)
    )

    return {
        "monthly": monthly_df.to_dict(orient="records"),
        "yearly": yearly_df.to_dict(orient="records")
    }


def detect_high_consumption(threshold=100):
    data = calculate_consumption()
    alerts = []

    for item in data:
        consumption = item["consumption_kwh"]

        # Ignore the first reading and invalid negative intervals.
        if consumption is None or consumption < 0:
            continue

        if consumption > threshold:
            alerts.append({
                "meter_code": item["meter_code"],
                "reading_date": item["reading_date"],
                "consumption_kwh": consumption,
                "threshold_kwh": threshold,
                "message": (
                    "Unusually high consumption. "
                    "Please review this reading."
                )
            })

    return alerts