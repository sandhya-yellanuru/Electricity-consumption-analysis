# Electricity-Consumption-Analysis
Electricity consumption monitoring and analysis using Flask and MySQL
