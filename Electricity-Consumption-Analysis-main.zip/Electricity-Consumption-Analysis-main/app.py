from flask import Flask, render_template, jsonify, request
from database import get_connection
import analysis

from analysis import (
    generate_consumption_chart,
    generate_consumption_summary,
    detect_high_consumption
)

from datetime import date
from math import isfinite

app = Flask(__name__)


# ------------------------------------------
# HOME PAGE
# ------------------------------------------

@app.route("/")
def home():
    try:
        generate_consumption_chart()
        return render_template("index.html")
    except Exception:
        app.logger.exception("Failed to load dashboard")
        return "Unable to load dashboard. Check the Flask terminal.", 500


# ------------------------------------------
# DATABASE DIAGNOSTIC
# ------------------------------------------

@app.route("/api/debug-database")
def debug_database():
    connection = None
    cursor = None

    try:
        connection = get_connection()
        cursor = connection.cursor(dictionary=True)

        cursor.execute("SELECT DATABASE() AS database_name")
        database_name = cursor.fetchone()

        cursor.execute(
            "SELECT COUNT(*) AS reading_count FROM meter_readings"
        )
        reading_count = cursor.fetchone()

        cursor.execute("""
            SELECT COUNT(*) AS joined_count
            FROM meter_readings AS r
            INNER JOIN meters AS m
                ON r.meter_id = m.meter_id
            INNER JOIN consumers AS c
                ON m.consumer_id = c.consumer_id
        """)
        joined_count = cursor.fetchone()

        return jsonify({
            "database": database_name["database_name"],
            "reading_count": reading_count["reading_count"],
            "joined_count": joined_count["joined_count"]
        })

    except Exception:
        app.logger.exception("Database diagnostic failed")
        return jsonify({
            "error": "Database diagnostic failed. Check the Flask terminal."
        }), 500

    finally:
        if cursor is not None:
            cursor.close()

        if connection is not None and connection.is_connected():
            connection.close()


# ------------------------------------------
# CONSUMERS
# ------------------------------------------

@app.route("/api/consumers")
def get_consumers():
    connection = None
    cursor = None

    try:
        connection = get_connection()
        cursor = connection.cursor(dictionary=True)

        cursor.execute("""
            SELECT consumer_id, consumer_type, region
            FROM consumers
            ORDER BY consumer_id
        """)

        return jsonify(cursor.fetchall())

    except Exception:
        app.logger.exception("Failed to fetch consumers")
        return jsonify({"error": "Unable to fetch consumers."}), 500

    finally:
        if cursor is not None:
            cursor.close()

        if connection is not None and connection.is_connected():
            connection.close()


# ------------------------------------------
# METERS
# ------------------------------------------

@app.route("/api/meters")
def get_meters():
    connection = None
    cursor = None

    try:
        connection = get_connection()
        cursor = connection.cursor(dictionary=True)

        cursor.execute("""
            SELECT
                m.meter_id,
                m.consumer_id,
                m.meter_code,
                c.consumer_type,
                c.region
            FROM meters AS m
            INNER JOIN consumers AS c
                ON m.consumer_id = c.consumer_id
            ORDER BY m.meter_id
        """)

        return jsonify(cursor.fetchall())

    except Exception:
        app.logger.exception("Failed to fetch meters")
        return jsonify({"error": "Unable to fetch meters."}), 500

    finally:
        if cursor is not None:
            cursor.close()

        if connection is not None and connection.is_connected():
            connection.close()


# ------------------------------------------
# ADD A METER
# ------------------------------------------

@app.route("/api/meters/add", methods=["POST"])
def add_meter():
    connection = None
    cursor = None

    try:
        data = request.get_json(silent=True) or {}

        consumer_id = data.get("consumer_id")
        meter_code = str(data.get("meter_code", "")).strip()

        if not consumer_id or not meter_code:
            return jsonify({
                "error": "Consumer ID and meter code are required."
            }), 400

        try:
            consumer_id = int(consumer_id)
        except (ValueError, TypeError):
            return jsonify({"error": "Invalid consumer ID."}), 400

        connection = get_connection()
        cursor = connection.cursor(dictionary=True)

        cursor.execute(
            "SELECT consumer_id FROM consumers WHERE consumer_id = %s",
            (consumer_id,)
        )

        if cursor.fetchone() is None:
            return jsonify({"error": "Consumer not found."}), 404

        cursor.execute(
            "SELECT meter_id FROM meters WHERE meter_code = %s",
            (meter_code,)
        )

        if cursor.fetchone() is not None:
            return jsonify({"error": "Meter code already exists."}), 409

        cursor.execute("""
            INSERT INTO meters (consumer_id, meter_code)
            VALUES (%s, %s)
        """, (consumer_id, meter_code))

        connection.commit()

        return jsonify({
            "message": "Meter added successfully.",
            "meter_id": cursor.lastrowid
        }), 201

    except Exception:
        if connection is not None and connection.is_connected():
            connection.rollback()

        app.logger.exception("Failed to add meter")
        return jsonify({"error": "Unable to add meter."}), 500

    finally:
        if cursor is not None:
            cursor.close()

        if connection is not None and connection.is_connected():
            connection.close()


# ------------------------------------------
# READINGS
# ------------------------------------------

@app.route("/api/readings")
def get_readings():
    connection = None
    cursor = None

    try:
        connection = get_connection()
        cursor = connection.cursor(dictionary=True)

        cursor.execute("""
            SELECT
                r.reading_id,
                r.meter_id,
                m.meter_code,
                r.reading_date,
                r.cumulative_kwh
            FROM meter_readings AS r
            INNER JOIN meters AS m
                ON r.meter_id = m.meter_id
            ORDER BY r.reading_date DESC, r.reading_id DESC
        """)

        readings = cursor.fetchall()

        for reading in readings:
            if reading["reading_date"] is not None:
                reading["reading_date"] = (
                    reading["reading_date"].strftime("%Y-%m-%d")
                )

        return jsonify(readings)

    except Exception:
        app.logger.exception("Failed to fetch readings")
        return jsonify({"error": "Unable to fetch readings."}), 500

    finally:
        if cursor is not None:
            cursor.close()

        if connection is not None and connection.is_connected():
            connection.close()


# ------------------------------------------
# ADD A READING
# ------------------------------------------

@app.route("/api/readings/add", methods=["POST"])
def add_reading():
    connection = None
    cursor = None

    try:
        data = request.get_json(silent=True) or {}

        meter_id = data.get("meter_id")
        reading_date = data.get("reading_date")
        cumulative_kwh = data.get("cumulative_kwh")

        if (
            meter_id is None
            or not reading_date
            or cumulative_kwh is None
        ):
            return jsonify({
                "error": "Meter ID, reading date and cumulative kWh are required."
            }), 400

        try:
            meter_id = int(meter_id)
            cumulative_kwh = float(cumulative_kwh)
            parsed_date = date.fromisoformat(str(reading_date))
        except (ValueError, TypeError):
            return jsonify({
                "error": "Enter a valid meter ID, date and cumulative kWh."
            }), 400

        if meter_id <= 0:
            return jsonify({"error": "Invalid meter ID."}), 400

        if not isfinite(cumulative_kwh) or cumulative_kwh < 0:
            return jsonify({
                "error": "Cumulative kWh must be a non-negative number."
            }), 400

        if parsed_date > date.today():
            return jsonify({
                "error": "Reading date cannot be in the future."
            }), 400

        connection = get_connection()
        cursor = connection.cursor(dictionary=True)

        cursor.execute(
            "SELECT meter_id FROM meters WHERE meter_id = %s",
            (meter_id,)
        )

        if cursor.fetchone() is None:
            return jsonify({"error": "Meter not found."}), 404

        cursor.execute("""
            SELECT reading_date, cumulative_kwh
            FROM meter_readings
            WHERE meter_id = %s
            ORDER BY reading_date DESC, reading_id DESC
            LIMIT 1
        """, (meter_id,))

        previous = cursor.fetchone()

        if previous is not None:
            previous_date = previous["reading_date"]

            if parsed_date <= previous_date:
                return jsonify({
                    "error": "The new reading date must be after the latest reading."
                }), 400

            if cumulative_kwh < float(previous["cumulative_kwh"]):
                return jsonify({
                    "error": "Cumulative kWh cannot be less than the previous reading."
                }), 400

        cursor.execute("""
            INSERT INTO meter_readings
                (meter_id, reading_date, cumulative_kwh)
            VALUES (%s, %s, %s)
        """, (meter_id, parsed_date, cumulative_kwh))

        connection.commit()

        return jsonify({
            "message": "Reading added successfully.",
            "reading_id": cursor.lastrowid
        }), 201

    except Exception:
        if connection is not None and connection.is_connected():
            connection.rollback()

        app.logger.exception("Failed to add reading")
        return jsonify({"error": "Unable to add reading."}), 500

    finally:
        if cursor is not None:
            cursor.close()

        if connection is not None and connection.is_connected():
            connection.close()


# ------------------------------------------
# CONSUMPTION ANALYSIS
# ------------------------------------------

@app.route("/api/consumption")
def consumption():
    try:
        # Use the analysis module directly.
        data = analysis.calculate_consumption()

        # Diagnostic information appears in the PyCharm terminal.
        print("ANALYSIS FILE:", analysis.__file__)
        print("CONSUMPTION RECORD COUNT:", len(data))
        print("CONSUMPTION RESULT:", data)

        # Keep the response as a JSON array for the dashboard.
        return jsonify(data), 200

    except Exception:
        app.logger.exception("Failed to calculate consumption")
        return jsonify({
            "error": "Unable to calculate consumption. Check the Flask terminal."
        }), 500


# ------------------------------------------
# MONTHLY AND YEARLY SUMMARY
# ------------------------------------------

@app.route("/api/summary")
def consumption_summary():
    try:
        summary = generate_consumption_summary()
        return jsonify(summary), 200

    except Exception:
        app.logger.exception("Failed to generate consumption summary")
        return jsonify({
            "error": "Unable to generate consumption summary."
        }), 500


# ------------------------------------------
# HIGH-CONSUMPTION ALERTS
# ------------------------------------------

@app.route("/api/alerts")
def consumption_alerts():
    try:
        alerts = detect_high_consumption()

        return jsonify({"alerts": alerts}), 200

    except Exception:
        app.logger.exception("Failed to detect high consumption")
        return jsonify({
            "error": "Unable to detect high consumption."
        }), 500


# ------------------------------------------
# RUN THE APPLICATION
# ------------------------------------------

if __name__ == "__main__":
    app.run(debug=True)
